# AGORA / Checkpoint

**Data:** 2026-10-22
**Estado real:** pacote de especificação criado; aplicação, repositório remoto, Docker, Nginx, DNS, banco, autenticação e integrações **não foram criados/testados neste pacote**.
**Entrega ativa:** E00 (preflight host) → E01 (login + shell/dashboard demo publicado se condições permitirem).
**Próxima ação:** ler `PROMPT_MESTRE_CLAUDE_CODE.md`, executar `scripts/preflight.sh` no host do usuário, escolher stack estável e iniciar scaffold Next.js.
**Testes executados:** validação de existência dos documentos e arquivo ZIP local. Nenhum teste da aplicação.
**Bloqueios conhecidos:** contexto do host desconhecido; DNS/TLS/capacidades de MCP não verificados; sem credenciais Cora/e-NF/e-mail nem dados reais autorizados.
**Regras importantes:** dois CNPJs, 51–150 clientes combinados, pós-pago M→M+1; quatro lotes (25, 1, 8, 15) com exceção NF conjunta dia 1; sem envio real até gate.
**Diretriz de segurança:** sem segredos, demo com etiqueta visível, login e HTTPS antes de dados reais.
**Branch/commit:** a preencher pelo agente.
**Próximo operador:** comece por `START_HERE.md`, `CLAUDE.md`, `docs/BACKLOG.md`.
